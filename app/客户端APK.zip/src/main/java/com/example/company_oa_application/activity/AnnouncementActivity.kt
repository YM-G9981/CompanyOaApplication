package com.example.company_oa_application.activity

import android.os.Bundle
import com.example.company_oa_application.R

class AnnouncementActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_announcement)
    }
}