package com.example.company_oa_application.entity.hrmResource

import java.io.Serializable
data class Position(val positionId: Long =0,val positionName: String?=null,val positionDescribe: String?=null): Serializable