package com.example.company_oa_application.fragment.meau.placeholder

import android.view.View

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 *
 * TODO: Replace all uses of this class before publishing your app.
 */
data class PlaceholderItem(val title: String, val iconResource: Int, val onClickListener: View.OnClickListener)
